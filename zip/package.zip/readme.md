## typescriptのメモ

気になった部分をメモしていく

#### 環境構築
https://qiita.com/Yuki-Kurita/items/5e449e2c05aaeeef80ac

1. npm init -y
1. npm install --save-dev typescript tslint @types/node
1. ./node_modules/.bin/tslint --init // tslint初期化
1. npx tslint --fix .\src\*.ts // tslintによる修正

```tslint.json
    "rules": {
        "semicolon": [
            true,
            "always"
          ]
    },
```

#### 